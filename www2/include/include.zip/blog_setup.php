<?php
    if ($cat == "food")
        $blog_title = "음식";
    elseif ($cat == "computer")
        $blog_title = "컴퓨터"; 
    elseif ($cat == "book")
        $blog_title = "도서"; 
    elseif ($cat == "talk")
        $blog_title = "이모저모"; 
    elseif ($cat == "notice")
        $blog_title = "공지사항";        
    else
        $blog_title = "전체글보기";    
?>